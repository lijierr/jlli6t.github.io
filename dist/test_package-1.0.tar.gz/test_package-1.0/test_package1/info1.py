

class Info1:
	def __init__(self):
		pass
	
	@staticmethod
	def print_hello():
		print('hello this is Info1.')

