
class Info2:
	def __init__(self):
		pass
	
	@staticmethod
	def print_hello2():
		print('Hellow, this is Info2.')

